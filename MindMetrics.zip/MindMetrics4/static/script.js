// --- Audio Recording Setup ---
let mediaRecorder;
let audioChunks = [];

document.getElementById("startRecord").addEventListener("click", async () => {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    mediaRecorder = new MediaRecorder(stream);
    mediaRecorder.start();
    audioChunks = [];

    mediaRecorder.addEventListener("dataavailable", e => {
        audioChunks.push(e.data);
    });

    document.getElementById("startRecord").disabled = true;
    document.getElementById("stopRecord").disabled = false;
});

document.getElementById("stopRecord").addEventListener("click", () => {
    mediaRecorder.stop();
    document.getElementById("startRecord").disabled = false;
    document.getElementById("stopRecord").disabled = true;

    mediaRecorder.addEventListener("stop", () => {
        const audioBlob = new Blob(audioChunks, { type: "audio/wav" });
        const audioFile = new File([audioBlob], "recorded_audio.wav", { type: "audio/wav" });
        document.getElementById("audioFile").file = audioFile;
    });
});

// --- Text Analysis ---
document.getElementById("analyzeText").addEventListener("click", async () => {
    const textFile = document.getElementById("textFile").files[0];
    const textInput = document.getElementById("textInput").value.trim();
    const formData = new FormData();

    if (textFile) formData.append("text_file", textFile);
    else if (textInput) formData.append("text", textInput);
    else return alert("Please upload or type text!");

    const res = await fetch("/predict_text", { method: "POST", body: formData });
    const data = await res.json();
    showResults(data);
});

// --- Audio Analysis ---
document.getElementById("analyzeAudio").addEventListener("click", async () => {
    const audioFile = document.getElementById("audioFile").files[0];
    if (!audioFile) return alert("Please upload or record audio!");

    const formData = new FormData();
    formData.append("audio", audioFile);

    const res = await fetch("/predict_audio", { method: "POST", body: formData });
    const data = await res.json();
    showResults(data);
});

// --- Combined Analysis ---
document.getElementById("analyzeBoth").addEventListener("click", async () => {
    const textFile = document.getElementById("textFile").files[0];
    const textInput = document.getElementById("textInput").value.trim();
    const audioFile = document.getElementById("audioFile").files[0];

    if ((!textFile && !textInput) || !audioFile)
        return alert("Please provide both text and audio!");

    const formData = new FormData();
    if (textFile) formData.append("text_file", textFile);
    else formData.append("text", textInput);
    formData.append("audio", audioFile);

    const res = await fetch("/predict_combined", { method: "POST", body: formData });
    const data = await res.json();
    showResults(data);
});

// --- Results Display ---
function showResults(data) {
    const resultsDiv = document.getElementById("results");
    document.getElementById("resultsSection").style.display = "block";

    let html = `<div class='mb-3'><h5>Prediction Probabilities:</h5></div>`;
    if (data.probabilities) {
        for (const [label, value] of Object.entries(data.probabilities)) {
            const percent = (value * 100).toFixed(1);
            html += `
                <div class="mb-2">
                    <label class="form-label">${label}: ${percent}%</label>
                    <div class="progress">
                        <div class="progress-bar" role="progressbar" style="width: ${percent}%">${percent}%</div>
                    </div>
                </div>`;
        }
    }

    if (data.summary) html += `<hr><p><strong>Summary:</strong> ${data.summary}</p>`;
    if (data.recommendation) html += `<p><strong>Recommendation:</strong> ${data.recommendation}</p>`;

    resultsDiv.innerHTML = html;
}
