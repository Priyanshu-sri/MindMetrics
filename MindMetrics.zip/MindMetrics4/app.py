# app.py — full file (replace your existing app.py with this)
from flask import Flask, render_template, request, jsonify, redirect, url_for, flash, send_from_directory, abort
from flask_sqlalchemy import SQLAlchemy
import joblib
import numpy as np
import pandas as pd
import librosa
import os
import tempfile
import language_tool_python
import shap
import matplotlib
matplotlib.use('Agg')   # headless backend for servers (prevents tkinter errors)
import matplotlib.pyplot as plt

# timezone handling
from datetime import datetime, timezone, timedelta
try:
    from zoneinfo import ZoneInfo
except Exception:
    ZoneInfo = None

# ---- Safe NLTK setup (avoid crash if corpora missing) ----
try:
    import nltk
    from nltk.corpus import stopwords
    try:
        stop_words = set(stopwords.words('english'))
    except LookupError:
        print("NLTK stopwords corpus not found. Using fallback stopword list.")
        stop_words = {
            'the','a','an','in','on','and','or','is','are','was','were','it','this','that',
            'of','to','for','with','as','by','at','from','be','have','has','had','but','not'
        }
except Exception as e:
    print("NLTK import error or corpora not available:", repr(e))
    stop_words = {
        'the','a','an','in','on','and','or','is','are','was','were','it','this','that',
        'of','to','for','with','as','by','at','from','be','have','has','had','but','not'
    }

from werkzeug.utils import secure_filename
import json

# ---------- Config ----------
BASE_DIR = os.path.abspath(os.path.dirname(__file__))
UPLOAD_FOLDER = os.path.join(BASE_DIR, 'uploads')
SHAP_FOLDER = os.path.join(BASE_DIR, 'static', 'shap_plots')
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(SHAP_FOLDER, exist_ok=True)

ALLOWED_EXT = {'wav', 'mp3', 'txt'}

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'dev-secret-key')
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL') or 'sqlite:///' + os.path.join(BASE_DIR, 'app.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

db = SQLAlchemy(app)

# ---------- DB Models ----------
class Patient(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    age = db.Column(db.Integer)
    gender = db.Column(db.String(20))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    analyses = db.relationship('Analysis', backref='patient', lazy=True, cascade="all, delete-orphan")

class Analysis(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    patient_id = db.Column(db.Integer, db.ForeignKey('patient.id'), nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    input_files = db.Column(db.Text)   # JSON list of filenames
    input_text = db.Column(db.Text)
    results = db.Column(db.Text)       # JSON string of model outputs
    summary = db.Column(db.Text)
    recommendation = db.Column(db.Text)

# ---------- Load Models ----------
# These files must exist under models/ as described earlier
text_model = joblib.load('models/stacked_text_model.pkl')
text_scaler = joblib.load('models/stacked_text_scaler.pkl')

audio_model = joblib.load('models/audio_model_stack.pkl')
audio_scaler = joblib.load('models/audio_scaler.pkl')
audio_threshold = joblib.load('models/audio_threshold.pkl')

# Load CSV template to match feature columns (used for text feature ordering)
template = pd.read_csv("models/transcript_features_labeled.csv").drop(columns=['label'], errors='ignore')

# Labels for prediction
labels = ['Control', 'Dementia']

# ---------- Helper Functions ----------
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXT

def extract_audio_features(file_path):
    """
    Extract MFCC-based features matching trained audio model (n_mfcc=25 used in training).
    Returns scaled features (1, n_audio_features).
    """
    try:
        y, sr = librosa.load(file_path, sr=None)
        mfcc = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=25)
        mfcc_mean = np.mean(mfcc.T, axis=0).reshape(1, -1)
        mfcc_scaled = audio_scaler.transform(mfcc_mean)
        return mfcc_scaled
    except Exception as e:
        app.logger.error(f"⚠️ Audio feature extraction error: {e}")
        try:
            n = audio_scaler.mean_.shape[0]
        except Exception:
            n = 25
        return np.zeros((1, n))

# Initialize grammar checker
try:
    tool = language_tool_python.LanguageTool('en-US')
except Exception as e:
    app.logger.warning("language_tool_python initialization failed: %s", e)
    tool = None

def extract_text_features(text):
    """
    Computes the text-based features and returns:
      - X_scaled (numpy array) ready for model
      - df_features (pandas DataFrame) original features in template order
      - feature_names list
    """
    words = text.split()
    num_words = len(words)
    unique_words = len(set(words))
    TTR = unique_words / num_words if num_words > 0 else 0

    sentences = [s.strip() for s in text.replace('!', '.').replace('?', '.').split('.') if s.strip()]
    avg_sentence_length = np.mean([len(s.split()) for s in sentences]) if sentences else 0

    grammar_errors = 0
    if tool:
        try:
            matches = tool.check(text)
            grammar_errors = len(matches)
        except Exception as e:
            app.logger.warning("LanguageTool check failed: %s", e)
            grammar_errors = 0

    stopword_count = sum(1 for w in words if w.lower() in stop_words)
    stopword_ratio = stopword_count / num_words if num_words > 0 else 0

    features = {
        'TTR': TTR,
        'Unique_Words': unique_words,
        'Avg_Sentence_Length': avg_sentence_length,
        'Grammar_Errors': grammar_errors,
        'Stopword_Ratio': stopword_ratio
    }

    df = pd.DataFrame([features])
    # Make sure template columns exist in df
    for col in template.columns:
        if col not in df.columns:
            df[col] = 0
    df = df[template.columns]
    X_scaled = text_scaler.transform(df.values)
    return X_scaled, df, list(df.columns)

def summarize_result(prob, source="text"):
    """
    Produce a clearer human-readable summary sentence and recommendation.
    """
    try:
        p = float(prob)
    except Exception:
        p = 0.0
    pred_label = labels[int(p >= 0.5)]
    confidence = round(float(p) * 100, 2)
    if pred_label == "Control":
        summary = f"Estimated dementia probability: {confidence}%. Model outcome: Control (lower risk)."
        recommendation = "No signs detected. Continue mental wellness activities and routine monitoring."
    else:
        summary = f"Estimated dementia probability: {confidence}%. Model outcome: Dementia (elevated risk)."
        recommendation = "Signs of dementia detected. Professional evaluation recommended."
    return summary, recommendation

def generate_text_shap_bar(X_scaled, feature_names, analysis_id):
    """
    Generate normalized SHAP bar plot (0..1 scale) saved to static/shap_plots.
    Returns filename (just the filename) or None on failure.
    """
    try:
        base_est = text_model
        if hasattr(text_model, 'named_estimators_') and 'xgb' in text_model.named_estimators_:
            base_est = text_model.named_estimators_['xgb']

        explainer = shap.TreeExplainer(base_est)
        shap_vals = explainer.shap_values(X_scaled)

        if isinstance(shap_vals, list):
            idx = 1 if len(shap_vals) > 1 else 0
            vals = np.array(shap_vals[idx]).reshape(X_scaled.shape)
        else:
            vals = np.array(shap_vals).reshape(X_scaled.shape)

        abs_vals = np.abs(vals[0])
        max_val = np.max(abs_vals) if np.max(abs_vals) != 0 else 1.0
        normalized_shap = abs_vals / max_val

        s = pd.Series(normalized_shap, index=feature_names)
        s_sorted = s.sort_values(ascending=True)

        figsize_x = 6
        figsize_y = max(2, 0.18 * len(feature_names))
        plt.figure(figsize=(figsize_x, figsize_y))
        s_sorted.plot(kind='barh')
        plt.title("SHAP Feature Importance (normalized, 0–1)")
        plt.xlabel("Normalized importance (0–1)")
        plt.tight_layout()

        fname = f"analysis_{analysis_id}.png"
        out_path = os.path.join(SHAP_FOLDER, fname)
        plt.savefig(out_path, dpi=120)
        plt.close()
        return fname
    except Exception as e:
        app.logger.error(f"Failed to generate SHAP plot: {e}")
        try:
            plt.close()
        except Exception:
            pass
        return None

def run_inference(uploaded_paths, text, analysis_id=None):
    """
    Run audio and text inference and create results dict.
    If analysis_id provided and text available, a SHAP plot will be generated and filename added to results['shap_plot'].
    Also produce human-friendly interpretation strings stored under results['interpretation'].
    """
    results = {}
    audio_prob = None
    text_prob = None

    # AUDIO
    audio_paths = [p for p in uploaded_paths if p.lower().endswith(('.wav', '.mp3'))]
    if audio_paths:
        X_audio = extract_audio_features(audio_paths[0])
        try:
            audio_prob = float(audio_model.predict_proba(X_audio)[0][1])
        except Exception as e:
            app.logger.error(f"Audio model predict failed: {e}")
            audio_prob = None
        if audio_prob is not None:
            results['audio_model'] = audio_prob

    # TEXT
    final_text = text or ""
    text_paths = [p for p in uploaded_paths if p.lower().endswith('.txt')]
    if text_paths:
        try:
            with open(text_paths[0], 'r', encoding='utf-8') as f:
                final_text = f.read()
        except Exception as e:
            app.logger.error("Error reading uploaded text file: %s", e)

    if final_text and len(final_text.strip()) > 0:
        X_text_scaled, df_text, feature_names = extract_text_features(final_text)
        try:
            text_prob = float(text_model.predict_proba(X_text_scaled)[0][1])
        except Exception as e:
            app.logger.error(f"Text model predict failed: {e}")
            text_prob = None
        if text_prob is not None:
            results['text_model'] = text_prob

            if analysis_id is not None:
                shap_fname = generate_text_shap_bar(X_text_scaled, feature_names, analysis_id)
                if shap_fname:
                    results['shap_plot'] = shap_fname

    # Combine
    if (audio_prob is not None) and (text_prob is not None):
        results['combined'] = float(0.5 * audio_prob + 0.5 * text_prob)
    elif audio_prob is not None:
        results['combined'] = audio_prob
    elif text_prob is not None:
        results['combined'] = text_prob
    else:
        results['combined'] = 0.5

    # Interpretations (human-readable)
    interpretations = {}
    if 'audio_model' in results:
        try:
            interpretations['audio_model'] = (
                "Detects some speech irregularities typical in early dementia."
                if float(results['audio_model']) >= 0.30 else
                "Audio speech patterns look within expected range."
            )
        except Exception:
            interpretations['audio_model'] = ""
    if 'text_model' in results:
        try:
            p_text = float(results['text_model'])
            if p_text < 0.30:
                interpretations['text_model'] = "Text/language seems mostly normal."
            elif p_text < 0.60:
                interpretations['text_model'] = "Text shows possible signs; monitor further."
            else:
                interpretations['text_model'] = "High likelihood of dementia-related language signs."
        except Exception:
            interpretations['text_model'] = ""
    interpretations['combined'] = (
        "Overall: lower risk (combined evidence weak)." if results.get('combined', 0.0) < 0.30 else
        ("Overall: moderate risk — consider follow-up." if results.get('combined', 0.0) < 0.60 else
         "Overall: high risk — professional evaluation recommended.")
    )
    results['interpretation'] = interpretations

    return results

# ---------- Routes ----------
@app.route('/')
def home():
    patients = Patient.query.order_by(Patient.created_at.desc()).all()
    return render_template('index.html', patients=patients)

@app.route('/patient/create', methods=['POST'])
def create_patient():
    name = request.form.get('name', '').strip()
    age = request.form.get('age', '')
    gender = request.form.get('gender', '')
    if not name:
        flash('Name is required', 'danger')
        return redirect(url_for('home'))
    try:
        age_val = int(age) if age else None
    except ValueError:
        age_val = None
    p = Patient(name=name, age=age_val, gender=gender)
    db.session.add(p)
    db.session.commit()
    flash('Patient created', 'success')
    return redirect(url_for('patient_detail', patient_id=p.id))

@app.route('/patient/<int:patient_id>')
def patient_detail(patient_id):
    p = Patient.query.get_or_404(patient_id)
    analyses = Analysis.query.filter_by(patient_id=patient_id).order_by(Analysis.timestamp.desc()).all()
    return render_template('patient_detail.html', patient=p, analyses=analyses)

# New analysis route (defines endpoint 'new_analysis')
@app.route('/analysis/new/<int:patient_id>', methods=['GET', 'POST'])
def new_analysis(patient_id):
    patient = Patient.query.get_or_404(patient_id)
    if request.method == 'POST':
        uploaded_files = []
        saved_paths = []
        os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

        files = request.files.getlist('files')
        for f in files:
            if f and allowed_file(f.filename):
                filename = secure_filename(f"{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S')}_{f.filename}")
                path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                f.save(path)
                uploaded_files.append(filename)
                saved_paths.append(path)

        input_text = request.form.get('input_text', '').strip() or None

        # create an analysis row first so we have an ID for the SHAP filename
        analysis = Analysis(patient_id=patient.id)
        db.session.add(analysis)
        db.session.flush()  # assign id without commit

        results = run_inference(saved_paths, input_text, analysis.id)

        combined_prob = results.get('combined', 0.5)
        summary, recommendation = summarize_result(combined_prob, source="combined (text + audio)")

        # save analysis
        analysis.input_files = json.dumps(uploaded_files)
        analysis.input_text = input_text
        analysis.results = json.dumps(results)
        analysis.summary = summary
        analysis.recommendation = recommendation
        db.session.commit()

        flash('Analysis completed and saved.', 'success')
        return redirect(url_for('view_analysis', analysis_id=analysis.id))

    return render_template('new_analysis.html', patient=patient)

# Register the same route again with endpoint 'analysis_new' so both names work.
# This ensures url_for('analysis_new', patient_id=...) will build successfully.
try:
    app.add_url_rule(
        '/analysis/new/<int:patient_id>',
        endpoint='analysis_new',
        view_func=new_analysis,
        methods=['GET', 'POST']
    )
except Exception as e:
    app.logger.debug("add_url_rule for 'analysis_new' skipped or failed: %s", e)

@app.route('/analysis/<int:analysis_id>')
def view_analysis(analysis_id):
    a = Analysis.query.get_or_404(analysis_id)
    results = json.loads(a.results) if a.results else {}
    files = json.loads(a.input_files) if a.input_files else []

    shap_plot = None
    if results.get('shap_plot'):
        shap_plot = url_for('static', filename=f"shap_plots/{results['shap_plot']}")

    interpretation = results.get('interpretation', {})

    # Convert timestamp to Asia/Kolkata for display
    ts = a.timestamp
    try:
        if ts is None:
            formatted_time = "Unknown"
        else:
            if ts.tzinfo is None:
                ts = ts.replace(tzinfo=timezone.utc)
            if ZoneInfo is not None:
                local = ts.astimezone(ZoneInfo("Asia/Kolkata"))
                formatted_time = local.strftime("%Y-%m-%d %H:%M (%Z)")
            else:
                local = ts + timedelta(hours=5, minutes=30)
                formatted_time = local.strftime("%Y-%m-%d %H:%M (IST)")
    except Exception as e:
        app.logger.warning("Failed to localize timestamp: %s", e)
        formatted_time = a.timestamp.strftime("%Y-%m-%d %H:%M") if a.timestamp else "Unknown"

    return render_template('view_analysis.html',
                           analysis=a,
                           results=results,
                           files=files,
                           shap_plot=shap_plot,
                           interpretation=interpretation,
                           formatted_time=formatted_time)

# serve uploaded files
@app.route('/uploads/<path:filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename, as_attachment=False)

# --- API endpoints (unchanged) ---
@app.route('/predict_text', methods=['POST'])
def predict_text():
    text = None
    if 'text_file' in request.files:
        text_file = request.files['text_file']
        text = text_file.read().decode('utf-8')
    elif 'text' in request.form:
        text = request.form['text']

    if not text:
        return jsonify({'error': 'No text provided'}), 400

    X_text = extract_text_features(text)[0]
    prob = text_model.predict_proba(X_text)[0][1]
    summary, recommendation = summarize_result(prob, "text")

    return jsonify({
        'probabilities': {'Control': float(1 - prob), 'Dementia': float(prob)},
        'summary': summary,
        'recommendation': recommendation
    })

@app.route('/predict_audio', methods=['POST'])
def predict_audio():
    if 'audio' not in request.files:
        return jsonify({'error': 'No audio provided'}), 400

    audio_file = request.files['audio']
    with tempfile.NamedTemporaryFile(delete=False, suffix=".wav") as tmp:
        audio_path = tmp.name
        audio_file.save(audio_path)

    X_audio = extract_audio_features(audio_path)
    try:
        prob = audio_model.predict_proba(X_audio)[0][1]
    except Exception as e:
        app.logger.error(f"Audio predict failed: {e}")
        prob = 0.5
    os.remove(audio_path)

    summary, recommendation = summarize_result(prob, "audio")

    return jsonify({
        'probabilities': {'Control': float(1 - prob), 'Dementia': float(prob)},
        'summary': summary,
        'recommendation': recommendation
    })

@app.route('/predict_combined', methods=['POST'])
def predict_combined():
    text = None
    if 'text_file' in request.files:
        text_file = request.files['text_file']
        text = text_file.read().decode('utf-8')
    elif 'text' in request.form:
        text = request.form['text']

    if not text or 'audio' not in request.files:
        return jsonify({'error': 'Please provide both text and audio'}), 400

    # Audio
    audio_file = request.files['audio']
    with tempfile.NamedTemporaryFile(delete=False, suffix=".wav") as tmp:
        audio_path = tmp.name
        audio_file.save(audio_path)
    X_audio = extract_audio_features(audio_path)
    try:
        audio_prob = audio_model.predict_proba(X_audio)[0][1]
    except Exception as e:
        app.logger.error(f"Audio predict failed: {e}")
        audio_prob = 0.5
    os.remove(audio_path)

    # Text
    X_text = extract_text_features(text)[0]
    try:
        text_prob = text_model.predict_proba(X_text)[0][1]
    except Exception as e:
        app.logger.error(f"Text predict failed: {e}")
        text_prob = 0.5

    combined_prob = (0.5 * audio_prob) + (0.5 * text_prob)
    summary, recommendation = summarize_result(combined_prob, "combined (text + audio)")

    return jsonify({
        'probabilities': {'Control': float(1 - combined_prob), 'Dementia': float(combined_prob)},
        'summary': summary,
        'recommendation': recommendation
    })

# CLI helper
@app.cli.command('initdb')
def initdb():
    db.create_all()
    print("Initialized the database.")

if __name__ == '__main__':
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
    os.makedirs(SHAP_FOLDER, exist_ok=True)
    with app.app_context():
        db.create_all()
        print("✅ Database tables ready")
    app.run(debug=True)
